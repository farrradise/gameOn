// DOM Elements
const submitBtn = document.querySelector(".btn-submit");


// Ajout évenement au click sur le bouton submit du modal
submitBtn.addEventListener('click', checkForm);



// Traitement de l'info
function checkForm(e) {
    e.preventDefault();

    // Création des variables avec les datas du formulaire
    let firstName = document.getElementById('first').value; 
    let lastName = document.getElementById('last').value; 
    let birthDate = document.getElementById('birthdate').value; 
    let quantity = document.getElementById('quantity').value; 
    let cities = document.querySelectorAll('[name="location"]');
    // city.style.border = "3px solid pink!important";



    // On vérifie que les champs Prénom et Nom ont un minimum de 2 caractères / ne sont pas vide.
    checkName(firstName);
    checkName(lastName);

    // L'adresse électronique est valide
    // checkEmail();

    // age legal minimum 18ans
    checkBirth(birthDate);

    // Pour le nombre de concours, une valeur numérique est saisie.
    checkGamesNb(quantity);

    //Une ville (un input radio) est sélectionnée.
    cities.forEach(function(city) {
        checkCity(city);
    });

    // La case des conditions générales est cochée
    // checkLegal();


    // si tout est bon on envoie une requete fetch  

    // sinon on laisse les données renseignées dans le formulaire

}


function checkName(name) {
    const regex = new RegExp('[a-zA-Z]{2,}');

    if (name) {
        console.log(regex.test(name));
    } else {
        // console.log(`ajoute un nom `);
    }
}


function checkBirth(date) {
    
    const today = new Date();
    let parts = date.split('-');
    let majorityInYears = 18 * 365.2425;

    // transformation de la string en objet type date
    date = new Date(date);
    date.setDate(date.getDate() + majorityInYears);

    
    if (date > today) {
        console.log('retourne info pas encore majeur');
    }

}


function checkGamesNb(quantity) {
    if (!isNaN(parseInt(quantity, 10))) {
        console.log("c'est un nombre");

    } else {

    }

}


function checkCity(city) {
    console.log(city.value);
}